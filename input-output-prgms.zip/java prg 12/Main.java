import java.util.Scanner;
public class Main{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        char b = sc.next().charAt(0);
        int c = (int)b;
        System.out.println(c);
    }
}