import java.util.Scanner;
public class Main{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
       int a = sc.nextInt();
       int b = sc.nextInt();
       int c = sc.nextInt();
       int d = sc.nextInt();
       int e = sc.nextInt();
     
       System.out.println("Marks in each sub:"+"\n"+"Tamil: "+a+"\n"+"Eng: "+b+"\n"+"Maths: "+c+"\n"+"Che: "+d+"\n"+"Phy: "+e);
    }
}